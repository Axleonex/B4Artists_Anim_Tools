"""UI subpackage, class collection for registration, and Bforartists detection."""

from __future__ import annotations

import bpy

# ---------------------------------------------------------------------------
# Bforartists detection – defined FIRST so that headers.py can safely do
# ``from . import is_bforartists`` without hitting a circular import.
# ---------------------------------------------------------------------------

IS_BFORARTISTS: bool = False


def is_bforartists() -> bool:
    return IS_BFORARTISTS


def init_detection() -> None:
    global IS_BFORARTISTS
    IS_BFORARTISTS = "bforartists" in bpy.app.version_string.lower()


# ---------------------------------------------------------------------------
# Import submodules *after* is_bforartists is defined.
# ---------------------------------------------------------------------------

from .diagnostics_panel import AA_PT_diagnostics  # noqa: E402
from .panels import classes as _panel_classes       # noqa: E402
from .menus import classes as _menu_classes         # noqa: E402
from .p2_panels import classes as _p2_panel_classes  # noqa: E402
# --- BREAKDOWN AND INBETWEEN TOOLS ---
from .p3_panels import CLASSES as _p3_panel_classes  # noqa: E402
# --- TRANSFORM OFFSET CONTROLS ---
from .p4_panels import CLASSES as _p4_panel_classes
# --- TRAJECTORY VISUALIZATION ---
from .p5_panels import CLASSES as _p5_panel_classes  # noqa: E402
# --- RETIMING AND TIMING DIAGNOSTICS ---
from .p6_panels import CLASSES as _p6_panel_classes  # noqa: E402
# --- PROXY AND BAKE CONTROLS ---
from .p7_panels import CLASSES as _p7_panel_classes  # noqa: E402
# --- MATCHING AND SPACE SWITCHING PANELS ---
from .p8_panels import CLASSES as _p8_panel_classes  # noqa: E402
# --- MIRRORING AND PAIR DETECTION PANELS ---
from .p9_panels import CLASSES as _p9_panel_classes  # noqa: E402
# --- ORCHESTRATION AND RECOVERY PANELS ---
from .p10_panels import CLASSES as _p10_panel_classes  # noqa: E402
from .p10_pie_menus import CLASSES as _p10_pie_menu_classes  # noqa: E402
# --- ANIMATION LAYER PANELS ---
from .p11_panels import CLASSES as _p11_panel_classes  # noqa: E402
from . import headers                               # noqa: E402
from . import header_toolbars                       # noqa: E402
# --- EXPLAINER SYSTEM EXTENSION ---
from .help_browser import classes as _help_browser_classes  # noqa: E402
# --- UI/UX FOUNDATION ---
# UI state PropertyGroup classes are sourced from core.ui_state and
# registered through this package's CLASSES tuple so they participate
# in the existing ClassRegistry rollback machinery.
from ..core import ui_state as _ui_state_mod        # noqa: E402
# Re-export the shared drawing helpers and editor placement mixins so
# future-phase panels can ``from ..ui import ui_helpers, scope_ui,
# editor_placement, panel_anatomy`` from a single namespace.
# Re-export shared drawing helpers for any panel that needs them.
from . import ui_helpers as ui_helpers              # noqa: E402, F401
from . import panel_anatomy as panel_anatomy        # noqa: E402, F401
from . import editor_placement as editor_placement  # noqa: E402, F401
from . import scope_ui as scope_ui                  # noqa: E402, F401

# ---------------------------------------------------------------------------
# Master class list – everything that goes through bpy.utils.register_class.
# Panels must be listed parent-before-child where bl_parent_id is used.
# UI state PropertyGroups are listed FIRST so the PointerProperty on
# WindowManager can resolve cleanly during ``register_properties``.
# ---------------------------------------------------------------------------

CLASSES: tuple[type, ...] = (
    # --- UI/UX FOUNDATION ---
    *_ui_state_mod.CLASSES,
    AA_PT_diagnostics,
    *_panel_classes,
    *_menu_classes,
    *_p2_panel_classes,
    # --- BREAKDOWN AND INBETWEEN TOOLS ---
    *_p3_panel_classes,
    # --- TRANSFORM OFFSET CONTROLS ---
    *_p4_panel_classes,
    # --- TRAJECTORY VISUALIZATION ---
    *_p5_panel_classes,
    # --- RETIMING AND TIMING DIAGNOSTICS ---
    *_p6_panel_classes,
    # --- PROXY AND BAKE CONTROLS ---
    *_p7_panel_classes,
    # --- MATCHING AND SPACE SWITCHING PANELS ---
    *_p8_panel_classes,
    # --- MIRRORING AND PAIR DETECTION PANELS ---
    *_p9_panel_classes,
    # --- ORCHESTRATION AND RECOVERY PANELS ---
    *_p10_panel_classes,
    *_p10_pie_menu_classes,
    # --- ANIMATION LAYER PANELS ---
    *_p11_panel_classes,
    # --- EXPLAINER SYSTEM EXTENSION ---
    *_help_browser_classes,
)
