"""Anim Assist – Production animation workflow tools that complement Animaide."""

bl_info = {
    "name": "Anim Assist",
    "author": "Developer",
    "version": (10, 0, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > AnimAssist",
    "description": "Production animation workflow tools for Bforartists (not compatible with standard Blender)",
    "category": "Animation",
}

from . import constants
from .core.logging import get_logger
from .core.registry import ClassRegistry
from .core import properties as prop_mod
from .core import cache as cache_mod
from .core import runtime as rts_mod
from .core import capabilities as cap_mod
from .core import hotkeys as hk_mod
from .core import migration as mig_mod
from .core import dispatch as dispatch_mod
# --- EXPLAINER SYSTEM EXTENSION ---
from .core import help_registry as help_reg_mod
from .core import help_phase1_entries as help_phase1_mod
# --- HELP SYSTEM INTEGRATION ---
from .core import help_phase2_entries as help_phase2_mod
# --- BREAKDOWN AND INBETWEEN TOOLS ---
from .core import help_phase3_entries as help_phase3_mod
from .core import p3_properties as p3_prop_mod
from .core import pose_compare as pose_compare_mod
from .core import breakdown_core as breakdown_core_mod
# --- TRANSFORM OFFSET CONTROLS ---
from .core import help_phase4_entries as help_phase4_mod
from .core import p4_properties as p4_prop_mod
from .core import p4_offset_math as p4_offset_math_mod
# --- DRAW SYSTEM FOUNDATION ---
from .core import draw_registry as dreg_mod
from .core import app_handlers as app_handlers_mod
# --- TRAJECTORY VISUALIZATION ---
from .core import help_phase5_entries as help_phase5_mod
from .core import p5_properties as p5_prop_mod
from .core import p5_path_cache as p5_cache_mod
# --- RETIMING AND TIMING DIAGNOSTICS ---
from .core import help_phase6_entries as help_phase6_mod
from .core import p6_properties as p6_prop_mod
# --- PROXY AND BAKE CONTROLS ---
from .core import help_phase7_entries as help_phase7_mod
from .core import p7_properties as p7_prop_mod
from .core import p7_session as p7_session_mod
# --- MATCHING AND SPACE SWITCHING ---
from .core import help_phase8_entries as help_phase8_mod
from .core import p8_properties as p8_prop_mod
from .core import p8_switch_history as p8_hist_mod
# --- MIRRORING AND PAIR DETECTION ---
from .core import help_phase9_entries as help_phase9_mod
from .core import p9_properties as p9_prop_mod
from .core import p9_pair_cache as p9_cache_mod
# --- ORCHESTRATION AND RECOVERY ---
from .core import help_phase10_entries as help_phase10_mod
from .core import p10_properties as p10_prop_mod
from .core import p10_tool_registry as p10_tool_reg_mod
from .core import p10_audit as p10_audit_mod
from .core import p10_recovery as p10_recovery_mod
# --- ANIMATION LAYER MANAGEMENT ---
from .core import help_phase11_entries as help_phase11_mod
from .core import p11_properties as p11_prop_mod
# --- UI STATE AND REGISTRATION ---
from .core import ui_state as ui_state_mod
from .prefs import AA_AddonPreferences
from . import operators as ops_pkg
from . import ui as ui_pkg

_log = get_logger(__name__)
_registry: ClassRegistry | None = None


def _build_registry() -> ClassRegistry:
    reg = ClassRegistry()
    # Property groups must be registered before PointerProperty attachment
    # and before any class that references them.
    reg.extend(prop_mod.CLASSES)
    reg.add(AA_AddonPreferences)

    # Foundation classes always register first.
    reg.extend(ops_pkg.CLASSES)
    reg.extend(ui_pkg.CLASSES)

    # Future module-gated registration hook:
    # from .prefs import get_prefs
    # prefs = get_prefs()
    # if prefs is None or prefs.enable_selection:
    #     reg.extend(selection_pkg.CLASSES)
    # if prefs is None or prefs.enable_keys:
    #     reg.extend(keys_pkg.CLASSES)
    # ... etc. for each module in constants.MODULE_KEYS

    return reg


def _is_bforartists() -> bool:
    """Return True when running inside Bforartists, False for standard Blender."""
    import bpy as _bpy

    # 1. Dedicated boolean attribute (may be added by future Bforartists builds).
    if getattr(_bpy.app, "bforartists", False):
        return True

    # 2. Build branch starts with "Bfa" (e.g. b'Bfa5v5.1.0 (modified)').
    build_branch = getattr(_bpy.app, "build_branch", b"")
    if isinstance(build_branch, bytes):
        build_branch = build_branch.decode("utf-8", errors="ignore")
    if build_branch.lower().startswith("bfa"):
        return True

    # 3. Binary path contains "bforartists" (e.g. F:\5.1.0\bforartists.exe).
    binary_path = getattr(_bpy.app, "binary_path", "")
    if "bforartists" in binary_path.lower():
        return True

    # 4. Version string contains "bforartists" (fallback for other builds).
    version_str = getattr(_bpy.app, "version_string", "")
    if "bforartists" in version_str.lower():
        return True

    return False


def register() -> None:
    if not _is_bforartists():
        raise RuntimeError(
            "Anim Assist is exclusive to Bforartists and cannot be used with "
            "standard Blender. Please install Bforartists: https://www.bforartists.de"
        )

    global _registry
    _registry = _build_registry()
    try:
        _registry.register()
        prop_mod.register_properties()
        # --- BREAKDOWN AND INBETWEEN TOOLS ---
        p3_prop_mod.register_properties()
        # --- TRANSFORM OFFSET CONTROLS ---
        p4_prop_mod.register_properties()
        # --- TRAJECTORY VISUALIZATION ---
        p5_prop_mod.register_properties()
        # --- RETIMING AND TIMING DIAGNOSTICS ---
        p6_prop_mod.register_properties()
        # --- PROXY AND BAKE CONTROLS ---
        p7_prop_mod.register_properties()
        # --- MATCHING AND SPACE SWITCHING ---
        p8_prop_mod.register_properties()
        # --- MIRRORING AND PAIR DETECTION ---
        p9_prop_mod.register_properties()
        # --- ORCHESTRATION AND RECOVERY ---
        p10_prop_mod.register_properties()
        # --- ANIMATION LAYER MANAGEMENT ---
        p11_prop_mod.register_properties()
        # --- UI STATE AND REGISTRATION ---
        # Attach the WindowManager-scoped UI state PointerProperty AFTER
        # the parent PropertyGroup classes have been registered above.
        ui_state_mod.register_properties()
        ui_pkg.headers.register()
        ui_pkg.header_toolbars.register()
        cache_mod.init()
        rts_mod.init()
        # --- DRAW SYSTEM FOUNDATION ---
        # Draw handler registry must init after runtime (it logs) but
        # before any module that might register draw handlers.
        dreg_mod.init()
        # App handlers (load_post, undo_post, redo_post) provide the
        # lifecycle events that keep draw handlers and caches in sync.
        app_handlers_mod.register()
        cap_mod.init()
        hk_mod.get_manager().register_defaults()

        # --- EXPLAINER SYSTEM EXTENSION ---
        # Seed foundation help entries. All modules register their own
        # help entries from the same place.
        try:
            help_phase1_mod.register()
        except Exception:
            _log.exception("Help registry seed failed \u2013 continuing")

        # --- HELP SYSTEM INTEGRATION ---
        try:
            help_phase2_mod.register()
        except Exception:
            _log.exception("Key editing help registry seed failed \u2013 continuing")

        # --- BREAKDOWN AND INBETWEEN TOOLS ---
        try:
            help_phase3_mod.register()
        except Exception:
            _log.exception("Breakdown help registry seed failed \u2013 continuing")

        # --- TRANSFORM OFFSET CONTROLS ---
        try:
            help_phase4_mod.register()
        except Exception:
            _log.exception("Offset help registry seed failed \u2013 continuing")

        # --- TRAJECTORY VISUALIZATION ---
        try:
            help_phase5_mod.register()
        except Exception:
            _log.exception("Trajectory help registry seed failed \u2013 continuing")

        # --- RETIMING AND TIMING DIAGNOSTICS ---
        try:
            help_phase6_mod.register()
        except Exception:
            _log.exception("Retiming help registry seed failed \u2013 continuing")

        # --- PROXY AND BAKE CONTROLS ---
        try:
            help_phase7_mod.register()
        except Exception:
            _log.exception("Proxy/bake help registry seed failed \u2013 continuing")

        try:
            help_phase8_mod.register()
        except Exception:
            _log.exception("Matching help registry seed failed \u2013 continuing")

        # --- MIRRORING AND PAIR DETECTION ---
        try:
            help_phase9_mod.register()
        except Exception:
            _log.exception("Mirroring help registry seed failed \u2013 continuing")

        # --- ORCHESTRATION AND RECOVERY ---
        try:
            help_phase10_mod.register()
        except Exception:
            _log.exception("Orchestration help registry seed failed \u2013 continuing")

        # --- ANIMATION LAYER MANAGEMENT ---
        try:
            help_phase11_mod.register()
        except Exception:
            _log.exception("Animation layer help registry seed failed \u2013 continuing")

        # Sync logging level from preferences if available.
        try:
            from .prefs import get_prefs
            from .core.logging import set_level

            prefs = get_prefs()
            if prefs is not None:
                set_level(bool(prefs.debug_mode))
        except Exception:
            _log.debug(
                "Could not sync logging level from preferences", exc_info=True
            )

        # Run scene migrations.
        try:
            mig_mod.migrate_all_scenes()
        except Exception:
            _log.exception("Migration failed \u2013 continuing")

        _log.info("Anim Assist %s registered", constants.ADDON_VERSION_STRING)

    except Exception:
        _log.exception("Registration failed; attempting rollback")
        # --- EXPLAINER SYSTEM EXTENSION ---
        try:
            # --- ANIMATION LAYER MANAGEMENT ---
            help_phase11_mod.unregister()
            # --- ORCHESTRATION AND RECOVERY ---
            help_phase10_mod.unregister()
            # --- MIRRORING AND PAIR DETECTION ---
            help_phase9_mod.unregister()
            # --- MATCHING AND SPACE SWITCHING ---
            help_phase8_mod.unregister()
            # --- PROXY AND BAKE CONTROLS ---
            help_phase7_mod.unregister()
            # --- RETIMING AND TIMING DIAGNOSTICS ---
            help_phase6_mod.unregister()
            # --- TRAJECTORY VISUALIZATION ---
            help_phase5_mod.unregister()
            # --- TRANSFORM OFFSET CONTROLS ---
            help_phase4_mod.unregister()
            # --- BREAKDOWN AND INBETWEEN TOOLS ---
            help_phase3_mod.unregister()
            # --- HELP SYSTEM INTEGRATION ---
            help_phase2_mod.unregister()
            help_phase1_mod.unregister()
            help_reg_mod.clear_all_help()
        except Exception:
            _log.debug("Help rollback failed", exc_info=True)
        try:
            p11_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Animation layer property rollback failed", exc_info=True)
        try:
            p10_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Orchestration property rollback failed", exc_info=True)
        try:
            p9_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Mirroring property rollback failed", exc_info=True)
        try:
            p8_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Matching property rollback failed", exc_info=True)
        try:
            p7_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Proxy/bake property rollback failed", exc_info=True)
        try:
            p6_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Retiming property rollback failed", exc_info=True)
        try:
            p5_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Trajectory property rollback failed", exc_info=True)
        try:
            p4_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Offset property rollback failed", exc_info=True)
        try:
            p3_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Breakdown property rollback failed", exc_info=True)
        for cleanup in (
            ui_pkg.header_toolbars.unregister,
            ui_pkg.headers.unregister,
            hk_mod.shutdown,
            cap_mod.shutdown,
            # --- DRAW SYSTEM FOUNDATION ---
            app_handlers_mod.unregister,
            dreg_mod.shutdown,
            rts_mod.shutdown,
            cache_mod.shutdown,
            # --- UI STATE AND REGISTRATION ---
            ui_state_mod.unregister_properties,
            prop_mod.unregister_properties,
        ):
            try:
                cleanup()
            except Exception:
                _log.debug(
                    "Rollback cleanup failed: %s", cleanup, exc_info=True
                )

        if _registry is not None:
            try:
                _registry.unregister()
            except Exception:
                _log.debug("Rollback class unregister failed", exc_info=True)
            _registry = None
        raise


def unregister() -> None:
    global _registry

    # --- EXPLAINER SYSTEM EXTENSION ---
    # Tear down help entries before classes so the popup operator can never
    # be invoked against a half-cleared registry. ``clear_all_help`` is the
    # defensive backstop in case a phase teardown left orphan rows behind.
    for help_cleanup in (
        # --- ANIMATION LAYER MANAGEMENT ---
        help_phase11_mod.unregister,
        # --- ORCHESTRATION AND RECOVERY ---
        help_phase10_mod.unregister,
        # --- MIRRORING AND PAIR DETECTION ---
        help_phase9_mod.unregister,
        # --- MATCHING AND SPACE SWITCHING ---
        help_phase8_mod.unregister,
        # --- PROXY AND BAKE CONTROLS ---
        help_phase7_mod.unregister,
        # --- RETIMING AND TIMING DIAGNOSTICS ---
        help_phase6_mod.unregister,
        # --- TRAJECTORY VISUALIZATION ---
        help_phase5_mod.unregister,
        # --- TRANSFORM OFFSET CONTROLS ---
        help_phase4_mod.unregister,
        # --- BREAKDOWN AND INBETWEEN TOOLS ---
        help_phase3_mod.unregister,
        # --- HELP SYSTEM INTEGRATION ---
        help_phase2_mod.unregister,
        help_phase1_mod.unregister,
        help_reg_mod.clear_all_help,
    ):
        try:
            help_cleanup()
        except Exception:
            _log.exception("Help teardown failed: %s", help_cleanup)

    def _p6_clear_singletons() -> None:
        # Wipe the retiming module-level caches so a disable/enable
        # cycle does not expose stale timing snapshots or gap/diag data
        # from a prior scene to the newly loaded one.
        try:
            from .operators.p6_retime_ops import clear_last_backup
            clear_last_backup()
        except Exception:
            _log.debug("p6 clear_last_backup failed", exc_info=True)
        try:
            from .operators.p6_gap_ops import clear_cached_gaps
            clear_cached_gaps()
        except Exception:
            _log.debug("p6 clear_cached_gaps failed", exc_info=True)
        try:
            from .operators.p6_diag_ops import clear_cached_diag
            clear_cached_diag()
        except Exception:
            _log.debug("p6 clear_cached_diag failed", exc_info=True)

    def _p4_clear_singletons() -> None:
        try:
            p4_offset_math_mod.clear_last()
        except Exception:
            _log.debug("p4 clear_last failed", exc_info=True)

    def _p3_clear_singletons() -> None:
        # Module-level breakdown state must be wiped so a disable/enable
        # cycle does not replay stale pose snapshots or "repeat last"
        # options that reference a prior scene.
        try:
            pose_compare_mod.clear()
        except Exception:
            _log.debug("p3 pose_compare.clear failed", exc_info=True)
        try:
            breakdown_core_mod._LAST_OPTIONS = None  # type: ignore[attr-defined]
        except Exception:
            _log.debug("p3 breakdown_core _LAST_OPTIONS reset failed", exc_info=True)

    for cleanup in (
        ui_pkg.header_toolbars.unregister,
        ui_pkg.headers.unregister,
        hk_mod.shutdown,
        dispatch_mod.clear,
        cap_mod.shutdown,
        # --- DRAW SYSTEM FOUNDATION ---
        # App handlers first (they reference draw_registry, cache, runtime),
        # then draw registry (removes all viewport handlers), then runtime
        # and cache last.
        app_handlers_mod.unregister,
        dreg_mod.shutdown,
        rts_mod.shutdown,
        cache_mod.shutdown,
        # --- ANIMATION LAYER MANAGEMENT ---
        p11_prop_mod.unregister_properties,
        # --- ORCHESTRATION AND RECOVERY ---
        p10_audit_mod.clear_all,
        p10_recovery_mod.clear_snapshots,
        p10_tool_reg_mod.clear,
        p10_prop_mod.unregister_properties,
        # --- MIRRORING AND PAIR DETECTION ---
        p9_cache_mod.clear_cache,
        p9_prop_mod.unregister_properties,
        # --- MATCHING AND SPACE SWITCHING ---
        p8_hist_mod.clear_history,
        p8_prop_mod.unregister_properties,
        # --- PROXY AND BAKE CONTROLS ---
        p7_session_mod.clear_all_sessions,
        p7_prop_mod.unregister_properties,
        # --- RETIMING AND TIMING DIAGNOSTICS ---
        _p6_clear_singletons,
        p6_prop_mod.unregister_properties,
        # --- TRAJECTORY VISUALIZATION ---
        p5_cache_mod.invalidate_all,
        p5_prop_mod.unregister_properties,
        # --- TRANSFORM OFFSET CONTROLS ---
        _p4_clear_singletons,
        p4_prop_mod.unregister_properties,
        # --- BREAKDOWN AND INBETWEEN TOOLS ---
        _p3_clear_singletons,
        p3_prop_mod.unregister_properties,
        # --- UI STATE AND REGISTRATION ---
        ui_state_mod.unregister_properties,
        prop_mod.unregister_properties,
    ):
        try:
            cleanup()
        except Exception:
            _log.exception("Cleanup failed during unregister: %s", cleanup)

    if _registry is not None:
        try:
            _registry.unregister()
        except Exception:
            _log.exception("Class registry unregister failed")
        finally:
            _registry = None

    _log.info("Anim Assist %s unregistered", constants.ADDON_VERSION_STRING)